module.exports = {
    Guild: {
        Owner: "772546533203247115",
        ProBot: "282859044593598464",
 }
}