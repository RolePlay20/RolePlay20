module.exports = {
    Bots: {
        BrodCast: 5,
        AutoLine: 10,
        Music: 12,
        AutoReply: 20,

 }
}