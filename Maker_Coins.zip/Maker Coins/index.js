require("dotenv").config()
const Discord = require("discord.js")
const client = new Discord.Client({intents:[Discord.IntentsBitField.Flags.Guilds,Discord.IntentsBitField.Flags.GuildMembers,Discord.IntentsBitField.Flags.GuildMessages,Discord.IntentsBitField.Flags.GuildVoiceStates,
Discord.IntentsBitField.Flags.MessageContent]})










const mongoose = require('mongoose')
mongoose.set('strictQuery', true);
mongoose.connect(process.env.mongoose).then((gg) => console.log(`DataBase Connected`))

client.on("ready", () =>{
  console.log("Logged in as " + client.user.tag)
})

const prefix = "-"
const { default: axios } = require("axios")
const BotsData = require("./Data/BotsInfo.js")
const CoinsData = require("./Data/Data.js")
const Data = require("./Data/GuildInfo.js")

const ms = require("ms")
client.on("messageCreate", async message =>{
  if(message.content === prefix+"setup"){
    if(!message.member.permissions.has(Discord.PermissionFlagsBits.Administrator))return;
    let row = new Discord.ActionRowBuilder()
    .addComponents(
      new Discord.StringSelectMenuBuilder()
      .setCustomId("botone")
      .setPlaceholder("Please Select Bot Type | من فضلك اختر نوع البوت")
      .addOptions([
        {
          value: "1",
          label: "Brodcast",
        },
        {
          value: "2",
          label: "Auto Line",
        },
        {
          value: "3",
          label: "Music",
        },
        {
          value : "4",
          label : "AutoReply"
        }
      ])
    )
    let row2 = new Discord.ActionRowBuilder()
    .addComponents(
      new Discord.ButtonBuilder()
      .setCustomId("del")
      .setEmoji("🗑️")
      .setLabel("Delete Bot")
      .setStyle(Discord.ButtonStyle.Danger),
    )
    let embed = new Discord.EmbedBuilder()
    .setColor(0x2f3136)
    .addFields({
      name: "BrodCast",
      value: `Price : **\`$${BotsData.Bots.BrodCast}\`**`,inline:true
    },{
      name: "AutoLine",
      value: `Price : **\`$${BotsData.Bots.AutoLine}\`**`,inline:true
    },{
      name: "MusicBot",
      value: `Price : **\`$${BotsData.Bots.Music}\`**`,inline:true
    },{
      name: "AutoReply",
      value: `Price : **\`$${BotsData.Bots.AutoReply}\`**`,inline:true
    })
    .setThumbnail(message.guild.iconURL({dynamic: true}))
    .setAuthor({name: message.author.username, iconURL: message.author.avatarURL({dynamic: true})})
    .setFooter({text: "Diamond Host - diamondstdio.com", iconURL: "https://cdn.discordapp.com/attachments/1159278459026149406/1170517253888954459/2c3bf11b86ee0f78.png?ex=65ff7124&is=65ecfc24&hm=c54b345ebb36ae5026cb78a4cf6590d289360c32d625dc1dda6a944048ba9095&"})
    message.channel.send({content: "This Api Powered By [Diamond Host](https://discord.gg/8S3EspE3SY) / Bot Coding By [ThailandCodes](https://discord.gg/J6p6Anx2zu)", components: [row, row2], embeds: [embed]})
  }
})
client.on("interactionCreate", async interaction =>{
  if(interaction.customId === "del"){
    let modal = new Discord.ModalBuilder()
    .setCustomId('del1')
    .setTitle("Delete Bot Token")
    let m =  new Discord.TextInputBuilder()
    .setCustomId('del2')
    .setLabel(`توكن`)
    .setPlaceholder(`من فضلك قم بوضع توكن البوت هنا`)
    .setStyle(Discord.TextInputStyle.Paragraph)
    .setMinLength(1)
    .setMaxLength(500)
    .setRequired(true)
    const b = new Discord.ActionRowBuilder().addComponents(m)
    modal.addComponents(b);
    interaction.showModal(modal)
  }
})


const talkedRecently = new Set();
client.on("messageCreate", async message => {
  if(message.content === prefix+"buy-coins"){
    if (talkedRecently.has(message.author.id)) {
      let embed = new EmbedBuilder()
        .setDescription(
  `
  من فضلك انتظر <t:${Math.floor((Date.now() + ms(3600000)) / 1000)}:R>
  للشراء مره اخرى
  `)
      message.channel.send({ embeds: [embed] });
    } else {
      talkedRecently.add(message.author.id);
      setTimeout(() => {
        talkedRecently.delete(message.author.id);
      }, ms(3600000));
      if(message.author.bot || !message.guild) return; 
      let embedme = new Discord.EmbedBuilder()
          .setDescription(
              `للحصول على الروم برجاء تحويل : [الرقم المراد تحويله] ، الى : <@${Data.Guild.Owner}> عن طريق الامر التالي :
              \`\`\`c ${Data.Guild.Owner} [الرقم المراد تحويله]\`\`\``
          )
          .setTitle("عملية شراء الكوينز")
          .setTimestamp()
          .setURL("https://youtube.com/c/ThailandCodes")
          .setFooter({ text: `لديك فقط 15 ثانيه لتحول فيهم`});

      message.channel.send({ embeds: [embedme] }).then(async (msg) => {
          const filter = (response) =>
              response.author.id === Data.Guild.ProBot &&
              response.content.includes(Data.Guild.Owner);
          const filteruser = (i) => i.user.id === message.author.id;
          const collector = message.channel.createMessageCollector({ filter, filteruser , max: 1, time: 15000 });
          
          collector.on("collect", async (response) => {
              const amountTransferred = response.content.match(/`([^`]*)`/)[1];
              let price = amountTransferred.replace("$", "")
              
              if(response.content.startsWith(`**:moneybag: | ${message.author.username}, has transferred \`$${price}\``)) {
                  console.table({
                      User : message.author.id,
                      Coins: price,
                  });
                  
                  let coin = await CoinsData.findOne({ UserId: message.author.id });
                  
                  if (!coin) {
                      await CoinsData.create({ 
                          UserId: message.author.id,
                          Coins: price
                      }).then(async () => {
                          return msg.edit({ content: `
                          Done Transfer To Your Account
                          Coins: **\`$${price}\`**
                          `, embeds: [] }) 
                      });
                  } else {
                      await CoinsData.findOneAndUpdate({ UserId: message.author.id },{$inc: {Coins: price}}).then(async () => {
                          return msg.edit({ content: `
                          Done Transfer To Your Account
                          Coins: **\`$${price}\`**
                          `, embeds: [] })
                      });
                  }
              }
          });
      });
  }
}
});

client.on("messageCreate", async message => {
  if(message.content === prefix+"my-coins"){
    let coin = await CoinsData.findOne({ UserId: message.author.id });
    if (!coin) {
      return message.reply({ content: "You don't have any coins" });
    } else {
      return message.reply({ content: `🪙 - You'r Blance : **\`$${coin.Coins}\`**` });
    }
  }
})


client.on("interactionCreate", async interaction => {
  if(!interaction.isStringSelectMenu()) return;
  let Coins = await CoinsData.findOne({ UserId: interaction.user.id });
  if(interaction.customId === "botone"){
    if(interaction.values[0] === "1"){
      if (!Coins) {
        return interaction.reply({ content: "You don't have any coins",ephemeral:true });
      }

      if (Coins.Coins < BotsData.Bots.BrodCast) {
        return interaction.reply({ content: "You don't have enough coins",ephemeral:true });
      }
    const modal = new Discord.ModalBuilder()
      .setCustomId('bro')
      .setTitle("Buy A Brodcast")
      let m =  new Discord.TextInputBuilder()
      .setCustomId('bro1')
      .setLabel(`توكن`)
      .setPlaceholder(`من فضلك قم بوضع توكن البوت هنا`)
      .setStyle(Discord.TextInputStyle.Paragraph)
      .setMinLength(1)
      .setMaxLength(500)
      .setRequired(true)
      const b = new Discord.ActionRowBuilder().addComponents(m)
      modal.addComponents(b);
      interaction.showModal(modal)
    }
    if(interaction.values[0] === "2"){
      if (!Coins) {
        return interaction.reply({ content: "You don't have any coins",ephemeral:true });
      }

      if (Coins.Coins < BotsData.Bots.AutoLine) {
        return interaction.reply({ content: "You don't have enough coins",ephemeral:true });
      }
      const modal = new Discord.ModalBuilder()
      .setCustomId('auto')
      .setTitle("Buy A AutoLine")
      let m =  new Discord.TextInputBuilder()
      .setCustomId('auto2')
      .setLabel(`توكن`)
      .setPlaceholder(`من فضلك قم بوضع توكن البوت هنا`)
      .setStyle(Discord.TextInputStyle.Paragraph)
      .setMinLength(1)
      .setMaxLength(500)
      .setRequired(true)
  
      const b = new Discord.ActionRowBuilder().addComponents(m)
      modal.addComponents(b);
      interaction.showModal(modal)
   
    }
    if(interaction.values[0] === "3"){
      if (!Coins) {
        return interaction.reply({ content: "You don't have any coins",ephemeral:true });
      }

      if (Coins.Coins < BotsData.Bots.Music) {
        return interaction.reply({ content: "You don't have enough coins",ephemeral:true });
      }
      const modal = new Discord.ModalBuilder()
      .setCustomId('music')
      .setTitle("Buy A MusicBot")
      let m =  new Discord.TextInputBuilder()
      .setCustomId('music3')
      .setLabel(`توكن`)
      .setPlaceholder(`من فضلك قم بوضع توكن البوت هنا`)
      .setStyle(Discord.TextInputStyle.Paragraph)
      .setMinLength(1)
      .setMaxLength(500)
      .setRequired(true)
  
      const b = new Discord.ActionRowBuilder().addComponents(m)
      modal.addComponents(b);
      interaction.showModal(modal)
    }
    if(interaction.values[0] === "4"){
      if (!Coins) {
        return interaction.reply({ content: "You don't have any coins",ephemeral:true });
      }

      if (Coins.Coins < BotsData.Bots.AutoReply) {
        return interaction.reply({ content: "You don't have enough coins",ephemeral:true });
      }
      const modal = new Discord.ModalBuilder()
      .setCustomId('autoreply')
      .setTitle("Buy A AutoReply")
      let m =  new Discord.TextInputBuilder()
      .setCustomId('autoreply3')
      .setLabel(`توكن`)
      .setPlaceholder(`من فضلك قم بوضع توكن البوت هنا`)
      .setStyle(Discord.TextInputStyle.Paragraph)
      .setMinLength(1)
      .setMaxLength(500)
      .setRequired(true)
  
      const b = new Discord.ActionRowBuilder().addComponents(m)
      modal.addComponents(b);
      interaction.showModal(modal)
    }
  }
})



client.on("interactionCreate", async modal => {
  if(!modal.isModalSubmit()) return;
  if(modal.customId === "bro"){
    let user = 0
    user = modal.user.id
    const bro = modal.fields.getTextInputValue('bro1')
    axios({
      method : "GET",
      url : `https://maker.diamondstdio.com/api/v1/maker/add`,
      headers : {
          token : bro, // ده توكن
          username : user, // ده اي دي العضو عادي اي عضو : [لو عايز تضيف اسمه عادي]
          runbot : "BrodCast",
  
  
          id : `772546533203247115`, // ده ايدي المشتري المفتاح غير قابل التعديل
          key : `ThailandCodes`, // ده المفتاح
      }
  }).then(async (data) => {
    let { Status , Code , Message } = data.data;
    if(Code == 1005) {
      modal.reply({content:`${Status}, Please enter data to send it correctly`,ephemeral:true})
        return;
    } else if(Code == 1006) {
      modal.reply({content:`${Status}, Sorry, the key already exists, but you are not the primary owner of it`,ephemeral:true})
        return;
    }  else if(Code == 1404) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1007) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1008) {
      modal.reply({content:`To reach a maximum limit for creating bots on this key, please inform customer service to add more`,ephemeral:true})
        return;
    } else if(Code == 1009) {
      modal.reply({content:`${Message}`,ephemeral:true})

        return;
    } else if(Code == 1010) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    }else {
      return modal.reply({content : `
Done Run Your BrodCast Bot
Bot Token: **\`${bro}\`**
`,ephemeral:true}).then(async() =>{
  await CoinsData.findOneAndUpdate({ UserId: modal.user.id },{$inc: {Coins: -BotsData.Bots.BrodCast}});
})
}
  })
  }
  if(modal.customId === "auto"){
    const auto = modal.fields.getTextInputValue('auto2')
    axios({
      method : "GET",
      url : `https://maker.diamondstdio.com/api/v1/maker/add`,
      headers : {
          token : auto, // ده توكن
          username : modal.user.id, // ده اي دي العضو عادي اي عضو : [لو عايز تضيف اسمه عادي]
          runbot : "AutoLine",
  
  
          id : `772546533203247115`, // ده ايدي المشتري المفتاح غير قابل التعديل
          key : `ThailandCodes`, // ده المفتاح
      }
  }).then(async (data) => {
    let { Status , Code , Message } = data.data;
    if(Code == 1005) {
      modal.reply({content:`${Status}, Please enter data to send it correctly`,ephemeral:true})
        return;
    } else if(Code == 1006) {
      modal.reply({content:`${Status}, Sorry, the key already exists, but you are not the primary owner of it`,ephemeral:true})
        return;
    }  else if(Code == 1404) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1007) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1008) {
      modal.reply({content:`To reach a maximum limit for creating bots on this key, please inform customer service to add more`,ephemeral:true})
        return;
    } else if(Code == 1009) {
      modal.reply({content:`${Message}`,ephemeral:true})

        return;
    } else if(Code == 1010) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    }else {
      return modal.reply({content : `
Done Run Your AutoLine Bot
Bot Token: **\`${auto}\`**
      `,ephemeral:true}).then(async() =>{
        await CoinsData.findOneAndUpdate({ UserId: modal.user.id },{$inc: {Coins: -BotsData.Bots.AutoLine}});
      })
    }
  })
  }
  if(modal.customId === "music"){
    const music = modal.fields.getTextInputValue('music3')
    axios({
      method : "GET",
      url : `https://maker.diamondstdio.com/api/v1/maker/add`,
      headers : {
          token : music, // ده توكن
          username : modal.user.id, // ده اي دي العضو عادي اي عضو : [لو عايز تضيف اسمه عادي]
          runbot : "Music",
          id : `772546533203247115`, // ده ايدي المشتري المفتاح غير قابل التعديل
          key : `ThailandCodes`,
      }
  }).then(async (data) => {
    let { Status , Code , Message } = data.data;
    if(Code == 1005) {
      modal.reply({content:`${Status}, Please enter data to send it correctly`,ephemeral:true})
        return;
    } else if(Code == 1006) {
      modal.reply({content:`${Status}, Sorry, the key already exists, but you are not the primary owner of it`,ephemeral:true})
        return;
    }  else if(Code == 1404) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1007) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1008) {
      modal.reply({content:`To reach a maximum limit for creating bots on this key, please inform customer service to add more`,ephemeral:true})
        return;
    } else if(Code == 1009) {
      modal.reply({content:`${Message}`,ephemeral:true})

        return;
    } else if(Code == 1010) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    }else {
      return modal.reply({content : `
Done Run Your Music Bot
Bot Token: **\`${music}\`**
      `,ephemeral:true}).then(async() =>{
        await CoinsData.findOneAndUpdate({ UserId: modal.user.id },{$inc: {Coins: -BotsData.Bots.Music}});
      })
    }
  })
  }
if(modal.customId === "autoreply"){
    const reply = modal.fields.getTextInputValue('autoreply3')
    axios({
      method : "GET",
      url : `https://maker.diamondstdio.com/api/v1/maker/add`,
      headers : {
          token : reply, // ده توكن
          username : modal.user.id, // ده اي دي العضو عادي اي عضو : [لو عايز تضيف اسمه عادي]
          runbot : "AutoReply",
          id : `772546533203247115`, // ده ايدي المشتري المفتاح غير قابل التعديل
          key : `ThailandCodes`,
      }
  }).then(async (data) => {
    let { Status , Code , Message } = data.data;
    if(Code == 1005) {
      modal.reply({content:`${Status}, Please enter data to send it correctly`,ephemeral:true})
        return;
    } else if(Code == 1006) {
      modal.reply({content:`${Status}, Sorry, the key already exists, but you are not the primary owner of it`,ephemeral:true})
        return;
    }  else if(Code == 1404) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1007) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    } else if(Code == 1008) {
      modal.reply({content:`To reach a maximum limit for creating bots on this key, please inform customer service to add more`,ephemeral:true})
        return;
    } else if(Code == 1009) {
      modal.reply({content:`${Message}`,ephemeral:true})

        return;
    } else if(Code == 1010) {
      modal.reply({content:`${Message}`,ephemeral:true})
        return;
    }else {
      return modal.reply({content : `
Done Run Your AutoReply Bot
Bot Token: **\`${reply}\`**
`,ephemeral:true}).then(async() =>{
  await CoinsData.findOneAndUpdate({ UserId: modal.user.id },{$inc: {Coins: -BotsData.Bots.AutoReply}});
})
}
  })
  }
  if(modal.customId === "del1"){
    const deletoken = modal.fields.getTextInputValue('del2')

    axios({
      method : "GET",
      url : `https://maker.diamondstdio.com/api/v1/maker/deleteToken`,
      headers : {
          token : deletoken, // ده توكن
          id : `772546533203247115`, // ده ايدي المشتري المفتاح غير قابل التعديل
          key : `ThailandCodes`, // ده المفتاح
      }
  })
modal.reply({content : `
Deleted Bot Token
Token: **\`${deletoken}\`**`,ephemeral:true})
  }
})









process.on("uncaughtException" , err => {
return;
})

process.on("unhandledRejection" , err => {
return;
})

process.on("rejectionHandled", error => {
  return;
});

client.login(process.env.token)